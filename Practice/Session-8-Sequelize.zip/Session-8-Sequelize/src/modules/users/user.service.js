export const gerUsers = (req, res, next) => {
    return res.json({ msg: "ok" });
}