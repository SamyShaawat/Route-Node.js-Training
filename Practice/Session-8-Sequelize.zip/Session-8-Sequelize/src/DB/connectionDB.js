import { Sequelize } from "sequelize";



const sequelize = new Sequelize("node", "root", "", {
  host: "127.0.0.1",
  dialect: "mysql"
})

export const checkConnectionDB = () => {
  sequelize.authenticate().then(() => {
    console.log("Authentication  successful for database connection");

  }).catch(err => {
    console.log('Authentication failed for database connection', err);

  });
}